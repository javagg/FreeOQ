/************************************************************************
 * Copyright(c) 1997-2007, SmartQuant Ltd. All rights reserved.         *
 *                                                                      *
 * This file is provided as is with no warranty of any kind, including  *
 * the warranty of design, merchantability and fitness for a particular *
 * purpose.                                                             *
 *                                                                      *
 * This software may not be used nor distributed without proper license *
 * agreement.                                                           *
 ************************************************************************/

using System;
using System.ComponentModel;
using System.Collections.Generic;

using OpenQuant.API;
using OpenQuant.API.Plugins;

using MBTCOMLib;
using MBTQUOTELib;
using MBTORDERSLib;

namespace SampleProviders.MBT
{
	public class MBTrading : UserProvider, IMbtQuotesNotify
	{
		// Constants
		private const string CATEGORY_SETTINGS = "Settings";

		// Class members
		private MbtComMgr manager;

		private MbtOrderClient orderClient;

		private string username;
		private string password;

		private bool quotesLoggedIn;
		private bool ordersLoggedIn;

		private Dictionary<string, Instrument> subscribedInstruments;

		private Dictionary<string, Order> pendingOrders;
		private Dictionary<string, Order> workingOrders;

		public MBTrading()
		{
			base.name        = "MBT Sample";
			base.description = "MBTrading (user version)";
			base.id          = 101;
			base.url         = "http://www.mbtrading.com";

			manager = null;

			orderClient = null;

			username = "";
			password = "";

			quotesLoggedIn = false;
			ordersLoggedIn = false;

			subscribedInstruments = new Dictionary<string, Instrument>();

			pendingOrders = new Dictionary<string, Order>();
			workingOrders = new Dictionary<string, Order>();
		}

		#region Settings

		[Category(CATEGORY_SETTINGS)]
		public string Username
		{
			get { return username; }
			set { username = value; }
		}

		[Category(CATEGORY_SETTINGS)]
		[PasswordPropertyText(true)]
		public string Password
		{
			get { return password; }
			set { password = value; }
		}

		#endregion

		#region Connect/Disconnect

		protected override bool IsConnected
		{
			get { return (quotesLoggedIn && ordersLoggedIn); }
		}

		protected override void Connect()
		{
			if (IsConnected)
			{
				EmitError("Already connected.");

				return;
			}

			if (manager == null)
			{
				manager = new MbtComMgrClass();

				manager.OnHealthUpdate += new IMbtComMgrEvents_OnHealthUpdateEventHandler(manager_OnHealthUpdate);

				orderClient = manager.OrderClient;

				orderClient.OnDemandMode = false;

				orderClient.OnHistoryAdded += new _IMbtOrderClientEvents_OnHistoryAddedEventHandler(orderClient_OnHistoryAdded);
			}

			manager.EnableSplash(false);
			orderClient.SilentMode = true;

			if (manager.DoLogin(9, username, password, ""))
			{
			}
			else
			{
				manager.Quotes.Connect();

				orderClient.Connect();
			}
		}

		protected override void Disconnect()
		{
			if (IsConnected)
			{
				manager.Quotes.UnadviseAll(this);
				manager.Quotes.Disconnect();

				subscribedInstruments.Clear();

				orderClient.Disconnect();
			}
		}

		protected override void Shutdown()
		{
			Disconnect();
		}

		private void manager_OnHealthUpdate(enumServerIndex index, enumConnectionState state)
		{
			switch (state)
			{
				case enumConnectionState.csLoggedIn:
					{
						bool check = true;

						switch (index)
						{
							case enumServerIndex.siQuotes:
								quotesLoggedIn = true;
								break;
							case enumServerIndex.siOrders:
								ordersLoggedIn = true;
								break;
							default:
								check = false;
								break;
						}

						if (check && IsConnected)
						{
							base.EmitConnected();
						}
					}
					break;
				case enumConnectionState.csDisconnected:
					{
						bool check = true;

						switch (index)
						{
							case enumServerIndex.siQuotes:
								quotesLoggedIn = false;
								break;
							case enumServerIndex.siOrders:
								ordersLoggedIn = false;
								break;
							default:
								check = false;
								break;
						}

						if (check &&
							quotesLoggedIn == false &&
							ordersLoggedIn == false)
						{
							base.EmitDisconnected();
						}
					}
					break;
			}
		}

		#endregion

		#region Subscribe/Unsubscribe

		protected override void Subscribe(Instrument instrument)
		{
			if (!IsConnected)
			{
				EmitError("Not connected.");

				return;
			}

			if (!subscribedInstruments.ContainsKey(instrument.Symbol))
			{
				subscribedInstruments.Add(instrument.Symbol, instrument);

				manager.Quotes.AdviseSymbol(this, instrument.Symbol, (int)enumQuoteServiceFlags.qsfLevelOne | (int)enumQuoteServiceFlags.qsfTimeAndSales);
			}
		}

		protected override void Unsubscribe(Instrument instrument)
		{
			if (!IsConnected)
			{
				EmitError("Not connected.");

				return;
			}

			if (subscribedInstruments.ContainsKey(instrument.Symbol))
			{
				manager.Quotes.UnadviseSymbol(this, instrument.Symbol, (int)enumQuoteServiceFlags.qsfLevelOne | (int)enumQuoteServiceFlags.qsfTimeAndSales);

				subscribedInstruments.Remove(instrument.Symbol);
			}
		}

		#region IMbtQuotesNotify Members

		public void OnLevel2Data(ref LEVEL2RECORD pRec)
		{
		}

		public void OnOptionsData(ref OPTIONSRECORD pRec)
		{
		}

		public void OnQuoteData(ref QUOTERECORD pQuote)
		{
			Instrument instrument;

			if (subscribedInstruments.TryGetValue(pQuote.bstrSymbol, out instrument))
			{
				base.EmitNewQuote(
					instrument,
					Clock.Now,
					pQuote.dBid,
					pQuote.lBidSize,
					pQuote.dAsk,
					pQuote.lAskSize);
			}
		}

		public void OnTSData(ref TSRECORD pRec)
		{
			Instrument instrument;

			if (subscribedInstruments.TryGetValue(pRec.bstrSymbol, out instrument))
			{
				base.EmitNewTrade(
					instrument,
					Clock.Now,
					pRec.dPrice,
					pRec.lSize);
			}
		}

		#endregion

		#endregion

		#region Orders

		protected override void Send(Order order)
		{
			if (!IsConnected)
			{
				EmitError("Not connected.");

				return;
			}

			// order side
			int orderSide;

			switch (order.Side)
			{
				case OrderSide.Buy:
					orderSide = 10000; // MBT constant
					break;
				case OrderSide.Sell:
					orderSide = 10001; // MBT constant
					break;
				default:
					{
						EmitError(string.Format("Not supported order side - {0}", order.Side));

						return;
					}
			}

			// order type and prices
			int orderType;
			double limitPrice;
			double stopPrice;

			switch (order.Type)
			{
				case OrderType.Market:
					{
						orderType  = 10031; // MBT constant
						limitPrice = 0;
						stopPrice  = 0;
					}
					break;
				case OrderType.Limit:
					{
						orderType  = 10030; // MBT constant
						limitPrice = order.Price;
						stopPrice  = 0;
					}
					break;
				case OrderType.Stop:
					{
						orderType  = 10073; // MBT constant
						limitPrice = 0;
						stopPrice  = order.StopPrice;
					}
					break;
				case OrderType.StopLimit:
					{
						orderType  = 10033; // MBT constant
						limitPrice = order.Price;
						stopPrice  = order.StopPrice;
					}
					break;
				default:
					{
						EmitError(string.Format("Not supported order type - {0}", order.Type));

						return;
					}
			}

			// time in force
			int tif;

			switch (order.TimeInForce)
			{
				case TimeInForce.Day:
					tif = 10011; // MBT constant
					break;
				case TimeInForce.GTC:
					tif = 10008; // MBT constant
					break;
				case TimeInForce.IOC:
					tif = 10010; // MBT constant
					break;
				default:
					{
						EmitError(string.Format("Not supported time in force - {0}", order.TimeInForce));

						return;
					}
			}

			// futures & options
			int expMonth       = 0;
			int expYear        = 0;
			double strikePrice = 0;

			if (order.Instrument.Type == InstrumentType.Futures ||
				order.Instrument.Type == InstrumentType.Option)
			{
				expMonth = order.Instrument.Maturity.Month;
				expYear  = order.Instrument.Maturity.Year;

				if (order.Instrument.Type == InstrumentType.Option)
					strikePrice = order.Instrument.Strike;
			}

			// send order
			string message = null;

			bool result = orderClient.Submit(
				orderSide,
				(int)order.Qty,
				order.Instrument.Symbol,
				limitPrice,
				stopPrice,
				tif,
				10020, // MBT constant (AGENCY)
				orderType,
				10042, // MBT constant (NORMAL)
				0,
				orderClient.Accounts[0],
				order.Instrument.Exchange,
				"",
				0,
				0,
				new DateTime(0),
				new DateTime(0),
				expMonth,
				expYear,
				strikePrice,
				"",
				0,
				-1,
				0,
				"",
				true,
				ref message);

			//
			if (result)
			{
				pendingOrders.Add(message, order);
			}
			else
			{
				base.EmitRejected(order, message);
			}
		}

		protected override void Cancel(Order order)
		{
			if (!IsConnected)
			{
				EmitError("Not connected.");

				return;
			}

			string orderNumber = null;

			foreach (KeyValuePair<string, Order> pair in workingOrders)
			{
				if (pair.Value == order)
				{
					orderNumber = pair.Key;

					break;
				}
			}

			if (orderNumber == null)
			{
				base.EmitError("Cannot cancel unknown order.");
			}
			else
			{
				string message = null;

				bool result = orderClient.Cancel(orderNumber, ref message);

				if (result)
				{
				}
				else
					base.EmitError(string.Format("Error cancelling order, OrderNumber={0} ,message={0}",
						orderNumber,
						message));
			}
		}

		private void orderClient_OnHistoryAdded(MbtOrderHistory pHist)
		{
			Order order;

			switch (pHist.Event)
			{
				case "Enter":
					{
						if (pendingOrders.TryGetValue(pHist.Token, out order))
						{
							pendingOrders.Remove(pHist.Token);
							workingOrders.Add(pHist.OrderNumber, order);
						}
						else
							EmitError(string.Format("OnHistoryAdded: Enter,unknown token - {0}", pHist.Token));
					}
					break;
				case "Live":
					{
						if (workingOrders.TryGetValue(pHist.OrderNumber, out order))
						{
							base.EmitAccepted(order);
						}
						else
							EmitError(string.Format("OnHistoryAdded: Live,unknown order number - {0}", pHist.OrderNumber));
					}
					break;
				case "Order Reject":
					{
						if (workingOrders.TryGetValue(pHist.OrderNumber, out order))
						{
							base.EmitRejected(order, pHist.Message);
						}
						else
							EmitError(string.Format("OnHistoryAdded: OrderReject,unknown order number - {0}", pHist.OrderNumber));
					}
					break;
				case "Executed":
					{
						if (workingOrders.TryGetValue(pHist.OrderNumber, out order))
						{
							base.EmitFilled(order, pHist.Price, pHist.Quantity);
						}
						else
							EmitError(string.Format("OnHistoryAdded: Executed,unknown order number - {0}", pHist.OrderNumber));
					}
					break;
				case "Cancel":
					{
						if (workingOrders.TryGetValue(pHist.OrderNumber, out order))
						{
							base.EmitPendingCancel(order);
						}
						else
							EmitError(string.Format("OnHistoryAdded: Cancel,unknown order number - {0}", pHist.OrderNumber));
					}
					break;
				case "Order Cancelled":
					{
						if (workingOrders.TryGetValue(pHist.OrderNumber, out order))
						{
							base.EmitCancelled(order);
						}
						else
							EmitError(string.Format("OnHistoryAdded: OrderCancel,unknown order number - {0}", pHist.OrderNumber));
					}
					break;
				case "Cancel Reject":
					{
						if (workingOrders.TryGetValue(pHist.OrderNumber, out order))
						{
							base.EmitCancelReject(order, order.Status, pHist.Message);
						}
						else
							EmitError(string.Format("OnHistoryAdded: CancelReject,unknown order number - {0}", pHist.OrderNumber));
					}
					break;
				case "Replace":
					{
						if (workingOrders.TryGetValue(pHist.OrderNumber, out order))
						{
							base.EmitPendingReplace(order);
						}
						else
							EmitError(string.Format("OnHistoryAdded: Replace,unknown order number - {0}", pHist.OrderNumber));
					}
					break;
				case "Successfully Replaced":
					{
						if (workingOrders.TryGetValue(pHist.OrderNumber, out order))
						{
							base.EmitReplaced(order);
						}
						else
							EmitError(string.Format("OnHistoryAdded: SuccessfullyReplaced,unknown order number - {0}", pHist.OrderNumber));
					}
					break;
				case "Replace Reject":
					{
						if (workingOrders.TryGetValue(pHist.OrderNumber, out order))
						{
							base.EmitReplaceReject(order, order.Status, pHist.Message);
						}
						else
							EmitError(string.Format("OnHistoryAdded: ReplaceReject,unknown order number - {0}", pHist.OrderNumber));
					}
					break;
				default:
					{
						EmitError(string.Format("OnHistoryAdded: unknown event - {0}", pHist.Event));
					}
					break;
			}
		}

		#endregion

		#region BrokerInfo

		protected override BrokerInfo GetBrokerInfo()
		{
			BrokerInfo brokerInfo = new BrokerInfo();

			if (IsConnected)
			{
				foreach (MbtAccount account in manager.OrderClient.Accounts)
				{
					BrokerAccount brokerAccount = brokerInfo.AddAccount(account.Account);

					// account fields
					brokerAccount.BuyingPower = account.CurrentBP;

					brokerAccount.AddField("Account", account.Account);
					brokerAccount.AddField("AcctType", account.AcctType.ToString());
					brokerAccount.AddField("Bank", account.Bank);
					brokerAccount.AddField("BaseCurrency", account.BaseCurrency);
					brokerAccount.AddField("Branch", account.Branch);
					brokerAccount.AddField("Credit", account.BaseCurrency, account.Credit.ToString());
					brokerAccount.AddField("CurrentBP", account.BaseCurrency, account.CurrentBP.ToString());
					brokerAccount.AddField("CurrentEquity", account.BaseCurrency, account.CurrentEquity.ToString());
					brokerAccount.AddField("CurrentExcess", account.BaseCurrency, account.CurrentExcess.ToString());
					brokerAccount.AddField("CurrentOvernightBP", account.BaseCurrency, account.CurrentOvernightBP.ToString());
					brokerAccount.AddField("Customer", account.Customer);
					brokerAccount.AddField("DailyRealizedPL", account.BaseCurrency, account.DailyRealizedPL.ToString());
					brokerAccount.AddField("MMRMultiplier", account.MMRMultiplier.ToString());
					brokerAccount.AddField("MMRUsed", account.MMRUsed.ToString());
					brokerAccount.AddField("MorningBP", account.BaseCurrency, account.MorningBP.ToString());
					brokerAccount.AddField("MorningCash", account.BaseCurrency, account.MorningCash.ToString());
					brokerAccount.AddField("MorningEquity", account.BaseCurrency, account.MorningEquity.ToString());
					brokerAccount.AddField("MorningExcess", account.BaseCurrency, account.MorningExcess.ToString());
					brokerAccount.AddField("MornOvernightBP", account.BaseCurrency, account.MornOvernightBP.ToString());
					brokerAccount.AddField("PermedForEquities", account.PermedForEquities.ToString());
					brokerAccount.AddField("PermedForForex", account.PermedForForex.ToString());
					brokerAccount.AddField("PermedForFutures", account.PermedForFutures.ToString());
					brokerAccount.AddField("PermedForOptions", account.PermedForOptions.ToString());
					brokerAccount.AddField("SemiDelimited", account.SemiDelimited);
					brokerAccount.AddField("State", account.State.ToString());
				}

				foreach (MbtPosition position in manager.OrderClient.Positions)
				{
					//
					BrokerAccount brokerAccount = brokerInfo.Accounts[position.Account.Account];

					BrokerPosition brokerPosition = brokerAccount.AddPosition();

					brokerPosition.Symbol = position.Symbol;

					if (position.AggregatePosition > 0)
						brokerPosition.LongQty = position.AggregatePosition;
					else
						brokerPosition.ShortQty = -position.AggregatePosition;

					brokerPosition.Qty = position.AggregatePosition;

					//
					brokerPosition.AddCustomField("AggregatePosition", position.AggregatePosition.ToString());
					brokerPosition.AddCustomField("CloseableShares", position.CloseableShares.ToString());
					brokerPosition.AddCustomField("Commision", position.Commission.ToString());
					brokerPosition.AddCustomField("IntradayPosition", position.IntradayPosition.ToString());
					brokerPosition.AddCustomField("IntradayPrice", position.IntradayPrice.ToString());
					brokerPosition.AddCustomField("MMRPct", position.MMRPct.ToString());
					brokerPosition.AddCustomField("MMRUsed", position.MMRUsed.ToString());
					brokerPosition.AddCustomField("OvernightPosition", position.OvernightPosition.ToString());
					brokerPosition.AddCustomField("OvernightPrice", position.OvernightPrice.ToString());
					brokerPosition.AddCustomField("PendingBuyShares", position.PendingBuyShares.ToString());
					brokerPosition.AddCustomField("PendingSellShares", position.PendingSellShares.ToString());
					brokerPosition.AddCustomField("RealizedPNL", position.RealizedPNL.ToString());
				}
			}

			return brokerInfo;
		}

		#endregion
	}
}
