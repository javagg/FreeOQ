/************************************************************************
 * Copyright(c) 1997-2007, SmartQuant Ltd. All rights reserved.         *
 *                                                                      *
 * This file is provided as is with no warranty of any kind, including  *
 * the warranty of design, merchantability and fitness for a particular *
 * purpose.                                                             *
 *                                                                      *
 * This software may not be used nor distributed without proper license *
 * agreement.                                                           *
 ************************************************************************/

using System;

using OpenQuant.API;

namespace SampleProviders.OEC
{
	class MarketDataRecord
	{
		public Instrument Instrument;

		public double Bid;
		public double Ask;
		public double Last;

		public int BidSize;
		public int AskSize;
		public int LastSize;

		public MarketDataRecord(Instrument instrument)
		{
			this.Instrument = instrument;

			Bid  = 0;
			Ask  = 0;
			Last = 0;

			BidSize  = 0;
			AskSize  = 0;
			LastSize = 0;
		}
	}
}
