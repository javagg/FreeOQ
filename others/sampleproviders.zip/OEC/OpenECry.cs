/************************************************************************
 * Copyright(c) 1997-2007, SmartQuant Ltd. All rights reserved.         *
 *                                                                      *
 * This file is provided as is with no warranty of any kind, including  *
 * the warranty of design, merchantability and fitness for a particular *
 * purpose.                                                             *
 *                                                                      *
 * This software may not be used nor distributed without proper license *
 * agreement.                                                           *
 ************************************************************************/

using System;
using System.ComponentModel;
using System.Collections.Generic;

using OpenQuant.API;

using OEC.API;
using OEC.Data;

namespace SampleProviders.OEC
{
	public class OpenECry : OpenQuant.API.Plugins.UserProvider
	{
		// Constants
		private const string CATEGORY_SETTINGS = "Settings";

		private const string DEFAULT_HOST = "sim.openecry.com";
		private const int    DEFAULT_PORT = 9200;

		private const string DEFAULT_USERNAME = "";
		private const string DEFAULT_PASSWORD = "";

		// Class members
		private string host;
		private int    port;

		private string username;
		private string password;

		private OECClient client;

		private Dictionary<string, MarketDataRecord> records;

		/// <summary>
		/// 
		/// </summary>
		public OpenECry()
		{
			base.name        = "OEC Sample";
			base.description = "Open E Cry (user version)";
			base.id          = 100;
			base.url         = "http://www.openecry.com";

			host = DEFAULT_HOST;
			port = DEFAULT_PORT;

			username = DEFAULT_USERNAME;
			password = DEFAULT_PASSWORD;

			records = new Dictionary<string, MarketDataRecord>();
		}

		#region Settings

		[Category(CATEGORY_SETTINGS)]
		[DefaultValue(DEFAULT_HOST)]
		public string Host
		{
			get { return host; }
			set { host = value; }
		}

		[Category(CATEGORY_SETTINGS)]
		[DefaultValue(DEFAULT_PORT)]
		public int Port
		{
			get { return port; }
			set { port = value; }
		}

		[Category(CATEGORY_SETTINGS)]
		[DefaultValue(DEFAULT_USERNAME)]
		public string Username
		{
			get { return username; }
			set { username = value; }
		}

		[Category(CATEGORY_SETTINGS)]
		[DefaultValue(DEFAULT_PASSWORD)]
		[PasswordPropertyText(true)]
		public string Password
		{
			get { return password; }
			set { password = value; }
		}

		#endregion

		#region Connect/Disconnect

		protected override void Connect()
		{
			if (base.isConnected)
				return; // already connected

			if (client == null)
			{
				client = new OECClient();

				client.OnLoginComplete += new OnLoginCompleteEvent(client_OnLoginComplete);
				client.OnLoginFailed   += new OnLoginFailedEvent(client_OnLoginFailed);
				client.OnDisconnected  += new OnDisconnectedEvent(client_OnDisconnected);
				client.OnError         += new OnErrorEvent(client_OnError);
				client.OnPriceTick     += new OnPriceChangedEvent(client_OnPriceTick);
			}

			try
			{
				client.Connect(host, port, username, password, false);
			}
			catch (Exception e)
			{
				base.EmitError(e.ToString());
			}
		}

		protected override void Disconnect()
		{
			if (!base.isConnected)
				return; // not connected

			client.Disconnect();
		}

		protected override void Shutdown()
		{
			Disconnect();
		}

		#endregion

		#region Subscribe/Unsubscribe

		protected override void Subscribe(Instrument instrument)
		{
			if (!base.isConnected)
			{
				EmitError("Not connected.");

				return;
			}

			global::OEC.API.Contract contract = client.Contracts[instrument.Symbol];

			if (contract == null)
			{
				base.EmitError(string.Format("Subscribe: No contract found for instrument {0}", instrument.Symbol));
			}
			else
			{
				try
				{
					if (!records.ContainsKey(contract.Symbol))
					{
						client.Subscribe(contract);

						records.Add(contract.Symbol, new MarketDataRecord(instrument));
					}
				}
				catch (Exception e)
				{
					base.EmitError(e.ToString());
				}
			}
		}

		protected override void Unsubscribe(Instrument instrument)
		{
			if (!base.isConnected)
			{
				EmitError("Not connected.");

				return;
			}

			global::OEC.API.Contract contract = client.Contracts[instrument.Symbol];

			if (contract == null)
			{
				base.EmitError(string.Format("Unsubscribe: No contract found for instrument {0}", instrument.Symbol));
			}
			else
			{
				try
				{
					if (records.ContainsKey(contract.Symbol))
					{
						client.Unsubscribe(contract);

						records.Remove(contract.Symbol);
					}
				}
				catch (Exception e)
				{
					base.EmitError(e.ToString());
				}
			}
		}

		#endregion

		#region Callbacks

		private void client_OnLoginComplete()
		{
			base.isConnected = true;

			base.EmitConnected();
		}

		private void client_OnLoginFailed(FailReason reason)
		{
			base.EmitError(string.Format("OnLoginFailed: {0}", reason));
		}

		private void client_OnDisconnected(bool unexpected)
		{
			if (unexpected)
				EmitError("Unexpected disconnect");

			records.Clear();

			base.isConnected = false;

			base.EmitDisconnected();
		}

		private void client_OnError(Exception ex)
		{
			base.EmitError(string.Format("OnError: {0}", ex));
		}

		private void client_OnPriceTick(global::OEC.API.Contract contract, global::OEC.API.Price price)
		{
			MarketDataRecord record;

			if (records.TryGetValue(contract.Symbol, out record))
			{
				bool diffBid  = (price.BidPrice != record.Bid || price.BidVol != record.BidSize);
				bool diffAsk  = (price.AskPrice != record.Ask || price.AskVol != record.AskSize);
				bool diffLast = (price.LastPrice != record.Last || price.LastVol != record.LastSize);

				if (diffLast)
					base.EmitNewTrade(record.Instrument, Clock.Now, price.LastPrice, price.LastVol);

				if (diffBid || diffAsk)
					base.EmitNewQuote(record.Instrument, Clock.Now, price.BidPrice, price.BidVol, price.AskPrice, price.AskVol);

				record.Bid  = price.BidPrice;
				record.Ask  = price.AskPrice;
				record.Last = price.LastPrice;

				record.BidSize  = price.BidVol;
				record.AskSize  = price.AskVol;
				record.LastSize = price.LastVol;
			}
		}

		#endregion
	}
}
