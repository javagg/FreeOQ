﻿/************************************************************************
 * Copyright(c) 1997-2008, SmartQuant Ltd. All rights reserved.         *
 *                                                                      *
 * This file is provided as is with no warranty of any kind, including  *
 * the warranty of design, merchantability and fitness for a particular *
 * purpose.                                                             *
 *                                                                      *
 * This software may not be used nor distributed without proper license *
 * agreement.                                                           *
 ************************************************************************/

using System;
using System.ComponentModel;

namespace SampleProviders.TT
{
	partial class TTFIX
	{
		//
		private int heartBtInt;

		private TimeSpan startTime;
		private TimeSpan endTime;

		private int reconnectInterval;

		private string beginString;

		private string dataDictionary;
		private string fileStorePath;
		private string fileLogPath;

		private bool checkLatency;
		private bool resetOnLogout;
		private bool resetOnDisconnect;

		private string priceSenderCompID;
		private string priceTargetCompID;
		private string priceSocketConnectHost;
		private int    priceSocketConnectPort;
		private string priceFileStorePath;

		private string orderSenderCompID;
		private string orderTargetCompID;
		private string orderSocketConnectHost;
		private int    orderSocketConnectPort;
		private string orderFileStorePath;

		private string password;

		private string account;
		private char   handlInst;
		private char   rule80A;
		private string clearingAccount;
		private int    customerOrFirm;

		#region Settings (Login)

		[Category("Login"), Description("Password")]
		[PasswordPropertyText(true)]
		public string Password
		{
			get { return password; }
			set { password = value; }
		}

		#endregion

		#region Execution defaults

		[Category("Execution Defaults")]
		[Description("Identifies the account associated with the order. Max supported length: 15")]
		public string Account
		{
			get { return account; }
			set { account = value; }
		}

		[Category("Execution Defaults")]
		[Description("Instructions for order handling on Broker trading floor that must be set to 1 (Automated execution order, private, no Broker intervention).")]
		public char HandlInst
		{
			get { return handlInst; }
			set { handlInst = value; }
		}

		[Category("Execution Defaults")]
		[Description("This Tag maps to X_TRADER™’s customer defaults. If present, must match the New Order message for this order.")]
		public char Rule80A
		{
			get { return rule80A; }
			set { rule80A = value; }
		}

		[Category("Execution Defaults")]
		[Description("Firm that clears the trade. Used if different from the executing firm.")]
		public string ClearingAccount
		{
			get { return clearingAccount; }
			set { clearingAccount = value; }
		}

		[Category("Execution Defaults")]
		[Description("Used for options when delivering the order to an execution system/exchange to specify if the order is for a customer or the firm placing the order itself. Valid Values - 0: Customer 1: Firm")]
		public int CustomerOrFirm
		{
			get { return customerOrFirm; }
			set { customerOrFirm = value; }
		}

		#endregion

		#region Settings (Defaults)

		[Category("Session Settings (Defaults)")]
		[Description("Heartbeat interval in seconds")]
		public int HeartBtInt
		{
			get { return heartBtInt; }
			set { heartBtInt = value; }
		}

		[Category("Session Settings (Defaults)")]
		[Description("Time of day that this FIX session becomes activated")]
		public TimeSpan StartTime
		{
			get { return startTime; }
			set { startTime = value; }
		}

		[Category("Session Settings (Defaults)")]
		[Description("Time of day that this FIX session becomes deactivated")]
		public TimeSpan EndTime
		{
			get { return endTime; }
			set { endTime = value; }
		}

		[Category("Session Settings (Defaults)")]
		[Description("Time between reconnection attempts in seconds")]
		public int ReconnectInterval
		{
			get { return reconnectInterval; }
			set { reconnectInterval = value; }
		}

		[Category("Session Settings (Defaults)")]
		[Description("Version of FIX this session should use")]
		public string BeginString
		{
			get { return beginString; }
			set { beginString = value; }
		}

		[Category("Session Settings (Defaults)")]
		[Description("XML definition file for validating incoming FIX messages. If no DataDictionary is supplied, only basic message validation will be done")]
		[Editor(typeof(System.Windows.Forms.Design.FileNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
		public string DataDictionary
		{
			get { return dataDictionary; }
			set { dataDictionary = value; }
		}

		[Category("Session Settings (Defaults)")]
		[Description("Directory to store sequence number and message files. Only used with FileStoreFactory.")]
		[Editor(typeof(System.Windows.Forms.Design.FolderNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
		public string FileStorePath
		{
			get { return fileStorePath; }
			set { fileStorePath = value; }
		}

		[Category("Session Settings (Defaults)")]
		[Description("Directory to store logs. Only used with FileLogFactory.")]
		[Editor(typeof(System.Windows.Forms.Design.FolderNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
		public string FileLogPath
		{
			get { return fileLogPath; }
			set { fileLogPath = value; }
		}

		[Category("Session Settings (Defaults)")]
		[Description("If set to TRUE, messages must be received from the counterparty within a defined number of seconds (see MaxLatency). It is useful to turn this off if a system uses localtime for it's timestamps instead of GMT")]
		public bool CheckLatency
		{
			get { return checkLatency; }
			set { checkLatency = value; }
		}

		[Category("Session Settings (Defaults)")]
		[Description("Determines if sequence numbers should be reset to 1 after a normal logout termination")]
		public bool ResetOnLogout
		{
			get { return resetOnLogout; }
			set { resetOnLogout = value; }
		}

		[Category("Session Settings (Defaults)")]
		[Description("Determines if sequence numbers should be reset to 1 after an abnormal termination")]
		public bool ResetOnDisconnect
		{
			get { return resetOnDisconnect; }
			set { resetOnDisconnect = value; }
		}

		#endregion

		#region Settings (Price)

		[Category("Session Settings (Price)")]
		[Description("Your ID as associated with this FIX session")]
		[DisplayName("SenderCompID")]
		public string PriceSenderCompID
		{
			get { return priceSenderCompID; }
			set { priceSenderCompID = value; }
		}

		[Category("Session Settings (Price)")]
		[Description("Counter parties ID as associated with this FIX session")]
		[DisplayName("TargetCompID")]
		public string PriceTargetCompID
		{
			get { return priceTargetCompID; }
			set { priceTargetCompID = value; }
		}

		[Category("Session Settings (Price)")]
		[Description("Host to connect to")]
		[DisplayName("SocketConnectHost")]
		public string PriceSocketConnectHost
		{
			get { return priceSocketConnectHost; }
			set { priceSocketConnectHost = value; }
		}

		[Category("Session Settings (Price)")]
		[Description("Socket port for connecting to a session")]
		[DisplayName("SocketConnectPort")]
		public int PriceSocketConnectPort
		{
			get { return priceSocketConnectPort; }
			set { priceSocketConnectPort = value; }
		}

		[Category("Session Settings (Price)")]
		[Description("Directory to store sequence number and message files. Only used with FileStoreFactory.")]
		[DisplayName("FileStorePath")]
		[Editor(typeof(System.Windows.Forms.Design.FolderNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
		public string PriceFileStorePath
		{
			get { return priceFileStorePath; }
			set { priceFileStorePath = value; }
		}

		#endregion

		#region Settings (Order)

		[Category("Session Settings (Order)")]
		[Description("Your ID as associated with this FIX session")]
		[DisplayName("SenderCompID")]
		public string OrderSenderCompID
		{
			get { return orderSenderCompID; }
			set { orderSenderCompID = value; }
		}

		[Category("Session Settings (Order)")]
		[Description("Counter parties ID as associated with this FIX session")]
		[DisplayName("TargetCompID")]
		public string OrderTargetCompID
		{
			get { return orderTargetCompID; }
			set { orderTargetCompID = value; }
		}

		[Category("Session Settings (Order)")]
		[Description("Host to connect to")]
		[DisplayName("SocketConnectHost")]
		public string OrderSocketConnectHost
		{
			get { return orderSocketConnectHost; }
			set { orderSocketConnectHost = value; }
		}

		[Category("Session Settings (Order)")]
		[Description("Socket port for connecting to a session")]
		[DisplayName("SocketConnectPort")]
		public int OrderSocketConnectPort
		{
			get { return orderSocketConnectPort; }
			set { orderSocketConnectPort = value; }
		}

		[Category("Session Settings (Order)")]
		[Description("Directory to store sequence number and message files. Only used with FileStoreFactory.")]
		[DisplayName("FileStorePath")]
		[Editor(typeof(System.Windows.Forms.Design.FolderNameEditor), typeof(System.Drawing.Design.UITypeEditor))]
		public string OrderFileStorePath
		{
			get { return orderFileStorePath; }
			set { orderFileStorePath = value; }
		}

		#endregion

		private void InitSettings()
		{
			// login
			Password = "12345678";

			// execution defaults
			HandlInst       = '1';
			Rule80A         = 'A';
			Account         = "TT";
			ClearingAccount = "";
			CustomerOrFirm  = 0;

			// defaults
			HeartBtInt        = 20;
			StartTime         = TimeSpan.Zero;
			EndTime           = TimeSpan.Zero;
			ReconnectInterval = 1;
			BeginString       = "FIX.4.2";
			DataDictionary    = @"C:\Program Files\SmartQuant Ltd\OpenQuant 2\Framework\fix\tt\FIX42_TT.xml";
			FileStorePath     = @"C:\Program Files\SmartQuant Ltd\OpenQuant 2\Framework\fix\tt\logs\tt";
			FileLogPath       = @"C:\Program Files\SmartQuant Ltd\OpenQuant 2\Framework\fix\tt\logs\tt";
			CheckLatency      = false;
			ResetOnLogout     = true;
			ResetOnDisconnect = true;

			// price
			PriceSenderCompID      = "tester";
			PriceTargetCompID      = "TT_PRICES";
			PriceSocketConnectHost = "localhost";
			PriceSocketConnectPort = 10502;
			PriceFileStorePath     = @"C:\Program Files\SmartQuant Ltd\OpenQuant 2\Framework\fix\tt\logs\price";

			// order
			OrderSenderCompID      = "tester";
			OrderTargetCompID      = "TT_ORDER";
			OrderSocketConnectHost = "localhost";
			OrderSocketConnectPort = 10501;
			OrderFileStorePath     = @"C:\Program Files\SmartQuant Ltd\OpenQuant 2\Framework\fix\tt\logs\order";
		}
	}
}
