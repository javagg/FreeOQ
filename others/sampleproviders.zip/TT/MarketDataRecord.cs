﻿/************************************************************************
 * Copyright(c) 1997-2008, SmartQuant Ltd. All rights reserved.         *
 *                                                                      *
 * This file is provided as is with no warranty of any kind, including  *
 * the warranty of design, merchantability and fitness for a particular *
 * purpose.                                                             *
 *                                                                      *
 * This software may not be used nor distributed without proper license *
 * agreement.                                                           *
 ************************************************************************/

using System;

using OpenQuant.API;

namespace SampleProviders.TT
{
	class MarketDataRecord : InstrumentRecord
	{
		/// <summary>
		/// 
		/// </summary>
		/// <param name="instrument"></param>
		public MarketDataRecord(Instrument instrument)
			: base(instrument)
		{
		}
	}
}
