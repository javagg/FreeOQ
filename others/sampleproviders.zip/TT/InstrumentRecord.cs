﻿/************************************************************************
 * Copyright(c) 1997-2008, SmartQuant Ltd. All rights reserved.         *
 *                                                                      *
 * This file is provided as is with no warranty of any kind, including  *
 * the warranty of design, merchantability and fitness for a particular *
 * purpose.                                                             *
 *                                                                      *
 * This software may not be used nor distributed without proper license *
 * agreement.                                                           *
 ************************************************************************/

using System;

using OpenQuant.API;

namespace SampleProviders.TT
{
	class InstrumentRecord
	{
		private Instrument instrument;

		/// <summary>
		/// 
		/// </summary>
		/// <param name="instrument"></param>
		protected InstrumentRecord(Instrument instrument)
		{
			this.instrument = instrument;
		}

		/// <summary>
		/// 
		/// </summary>
		public Instrument Instrument
		{
			get { return instrument; }
		}
	}
}
