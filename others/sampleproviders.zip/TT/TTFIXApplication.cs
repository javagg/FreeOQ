﻿/************************************************************************
 * Copyright(c) 1997-2008, SmartQuant Ltd. All rights reserved.         *
 *                                                                      *
 * This file is provided as is with no warranty of any kind, including  *
 * the warranty of design, merchantability and fitness for a particular *
 * purpose.                                                             *
 *                                                                      *
 * This software may not be used nor distributed without proper license *
 * agreement.                                                           *
 ************************************************************************/

using System;
using System.Collections.Specialized;
using System.Collections.Generic;

using OpenQuant.API;

using QuickFix;

namespace SampleProviders.TT
{
	class TTFIXApplication : MessageCracker, Application
	{
		//
		private TTFIX provider;

		private SessionID priceSessionID;
		private SessionID orderSessionID;

		private Dictionary<string, MarketDataRecord> marketDataRecords;

		private Dictionary<Instrument, string> mdReqIDs;

		private Dictionary<string, Order> orders;

		/// <summary>
		/// 
		/// </summary>
		/// <param name="provider"></param>
		/// <param name="priceSessionID"></param>
		/// <param name="orderSessionID"></param>
		public TTFIXApplication(
			TTFIX provider,
			SessionID priceSessionID,
			SessionID orderSessionID)
		{
			this.provider = provider;

			this.priceSessionID = priceSessionID;
			this.orderSessionID = orderSessionID;

			marketDataRecords = new Dictionary<string, MarketDataRecord>();

			mdReqIDs = new Dictionary<Instrument, string>();

			orders = new Dictionary<string, Order>();
		}

		#region Application Members

		public void fromAdmin(Message __p1, SessionID __p2)
		{
		}

		public void fromApp(Message __p1, SessionID __p2)
		{
			crack(__p1, __p2);
		}

		public void onCreate(SessionID __p1)
		{
		}

		public void onLogon(SessionID __p1)
		{
			Session priceSession = Session.lookupSession(priceSessionID);
			Session orderSession = Session.lookupSession(orderSessionID);

			if (priceSession != null && orderSession != null)
			{
				if (priceSession.isLoggedOn() && orderSession.isLoggedOn())
					provider.OnLogon();
			}
		}

		public void onLogout(SessionID __p1)
		{
			Session priceSession = Session.lookupSession(priceSessionID);
			Session orderSession = Session.lookupSession(orderSessionID);

			if (priceSession != null && orderSession != null)
			{
				if (!priceSession.isLoggedOn() && !orderSession.isLoggedOn())
				{
					marketDataRecords.Clear();
					mdReqIDs.Clear();
					orders.Clear();

					provider.OnLogout();
				}
			}
		}

		public void toAdmin(Message __p1, SessionID __p2)
		{
			if (__p1 is QuickFix42.Logon)
			{
				__p1.setField(new ResetSeqNumFlag(true));

				// set password
				string password = provider.Password;

				__p1.setField(new RawDataLength(password.Length));
				__p1.setField(new RawData(password));
				__p1.setField(new Password(password));
			}
		}

		public void toApp(Message __p1, SessionID __p2)
		{
		}

		#endregion

		/// <summary>
		/// 
		/// </summary>
		public void Connect()
		{
			Session session;

			// price session
			session = Session.lookupSession(priceSessionID);

			if (session != null && !session.isLoggedOn())
				session.logon();

			// order session
			session = Session.lookupSession(orderSessionID);

			if (session != null && !session.isLoggedOn())
				session.logon();
		}

		/// <summary>
		/// 
		/// </summary>
		public void Disconnect()
		{
			Session session;

			// price session
			session = Session.lookupSession(priceSessionID);

			if (session != null && session.isLoggedOn())
				session.logout();

			// order session
			session = Session.lookupSession(orderSessionID);

			if (session != null && session.isLoggedOn())
				session.logout();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="instrument"></param>
		/// <param name="subscribe"></param>
		public void SendMarketDataRequest(Instrument instrument, bool subscribe)
		{
			// prepare request
			string mdReqID               = Guid.NewGuid().ToString();
			char subscriptionRequestType = (subscribe) ?
				SubscriptionRequestType.SNAPSHOT_PLUS_UPDATES :
				SubscriptionRequestType.DISABLE_PREVIOUS_SNAPSHOT_PLUS_UPDATE_REQUEST;

			QuickFix42.MarketDataRequest request = new QuickFix42.MarketDataRequest(
				new MDReqID(mdReqID),
				new SubscriptionRequestType(subscriptionRequestType),
				new MarketDepth(1));

			request.set(new MDUpdateType(1));
			request.set(new AggregatedBook(true));

			QuickFix42.MarketDataRequest.NoMDEntryTypes typeGroup;

			typeGroup = new QuickFix42.MarketDataRequest.NoMDEntryTypes();
			typeGroup.set(new MDEntryType(MDEntryType.BID));
			request.addGroup(typeGroup);
			typeGroup.Dispose();

			typeGroup = new QuickFix42.MarketDataRequest.NoMDEntryTypes();
			typeGroup.set(new MDEntryType(MDEntryType.OFFER));
			request.addGroup(typeGroup);
			typeGroup.Dispose();

			typeGroup = new QuickFix42.MarketDataRequest.NoMDEntryTypes();
			typeGroup.set(new MDEntryType(MDEntryType.TRADE));
			request.addGroup(typeGroup);
			typeGroup.Dispose();

			QuickFix42.MarketDataRequest.NoRelatedSym symGroup = new QuickFix42.MarketDataRequest.NoRelatedSym();

			//
			symGroup.set(new Symbol(instrument.GetSymbol(TTFIX.PROVIDER_NAME)));
			symGroup.set(new SecurityExchange(instrument.GetExchange(TTFIX.PROVIDER_NAME)));

			switch (instrument.Type)
			{
				case InstrumentType.Stock:
					symGroup.set(new SecurityType(SecurityType.COMMON_STOCK));
					break;
				case InstrumentType.Index:
					symGroup.set(new SecurityType("IDX"));
					break;
				case InstrumentType.FX:
					symGroup.set(new SecurityType(SecurityType.FOREIGN_EXCHANGE_CONTRACT));
					break;
				case InstrumentType.Futures:
					symGroup.set(new SecurityType(SecurityType.FUTURE));
					symGroup.set(new MaturityMonthYear(instrument.Maturity.ToString("yyyyMM")));
					break;
				case InstrumentType.Option:
					symGroup.set(new SecurityType(SecurityType.OPTION));
					symGroup.set(new MaturityMonthYear(instrument.Maturity.ToString("yyyyMM")));

					switch (instrument.PutCall)
					{
						case PutCall.Call:
							symGroup.set(new PutOrCall(PutOrCall.CALL));
							break;
						case PutCall.Put:
							symGroup.set(new PutOrCall(PutOrCall.PUT));
							break;
					}

					symGroup.set(new StrikePrice(instrument.Strike));
					break;
				case InstrumentType.MultiLeg:
					symGroup.set(new SecurityType(SecurityType.MULTI_LEG_INSTRUMENT));
					break;
			}

			request.addGroup(symGroup);

			symGroup.Dispose();

			//
			if (subscribe)
			{
				if (!mdReqIDs.ContainsKey(instrument))
				{
					mdReqIDs.Add(instrument, mdReqID);
					marketDataRecords.Add(mdReqID, new MarketDataRecord(instrument));

					Session.sendToTarget(request, priceSessionID);
				}
			}
			else
			{
				if (mdReqIDs.ContainsKey(instrument))
				{
					string requestID = mdReqIDs[instrument];

					mdReqIDs.Remove(instrument);
					marketDataRecords.Remove(requestID);

					request.set(new MDReqID(requestID));

					Session.sendToTarget(request, priceSessionID);
				}
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="order"></param>
		public void SendNewOrderSingle(Order order)
		{
			string clOrdID = Guid.NewGuid().ToString();

			QuickFix42.NewOrderSingle message = new QuickFix42.NewOrderSingle();

			message.set(new ClOrdID(clOrdID));
			message.set(new HandlInst(provider.HandlInst));

			message.set(new Symbol(order.Instrument.GetSymbol(TTFIX.PROVIDER_NAME)));
			message.set(new SecurityExchange(order.Instrument.GetExchange(TTFIX.PROVIDER_NAME)));

			switch (order.Side)
			{
				case OrderSide.Buy:
					message.set(new Side(Side.BUY));
					break;
				case OrderSide.Sell:
					message.set(new Side(Side.SELL));
					break;
			}

			message.set(new TransactTime(order.DateTime));

			switch (order.Type)
			{
				case OrderType.Market:
					{
						message.set(new OrdType(OrdType.MARKET));
					}
					break;
				case OrderType.Limit:
					{
						message.set(new OrdType(OrdType.LIMIT));
						message.set(new Price(order.Price));
					}
					break;
				case OrderType.Stop:
					{
						message.set(new OrdType(OrdType.STOP));
						message.set(new StopPx(order.StopPrice));
					}
					break;
				case OrderType.StopLimit:
					{
						message.set(new OrdType(OrdType.STOP_LIMIT));
						message.set(new Price(order.Price));
						message.set(new StopPx(order.StopPrice));
					}
					break;
			}

			message.set(new OrderQty(order.Qty));

			switch (order.Instrument.Type)
			{
				case InstrumentType.Stock:
					{
						message.set(new SecurityType(SecurityType.COMMON_STOCK));
					}
					break;
				case InstrumentType.Index:
					{
						message.set(new SecurityType("IDX"));
					}
					break;
				case InstrumentType.FX:
					{
						message.set(new SecurityType(SecurityType.FOREIGN_EXCHANGE_CONTRACT));
					}
					break;
				case InstrumentType.Futures:
					{
						message.set(new SecurityType(SecurityType.FUTURE));
						message.set(new MaturityMonthYear(order.Instrument.Maturity.ToString("yyyyMM")));
					}
					break;
				case InstrumentType.Option:
					{
						message.set(new SecurityType(SecurityType.OPTION));
						message.set(new MaturityMonthYear(order.Instrument.Maturity.ToString("yyyyMM")));

						switch (order.Instrument.PutCall)
						{
							case PutCall.Put:
								message.set(new PutOrCall(PutOrCall.PUT));
								break;
							case PutCall.Call:
								message.set(new PutOrCall(PutOrCall.CALL));
								break;
						}

						message.set(new StrikePrice(order.Instrument.Strike));
					}
					break;
			}

			if (order.Account != string.Empty)
				message.set(new Account(order.Account));
			else
				message.set(new Account(provider.Account));

			message.set(new Rule80A(provider.Rule80A));
			message.set(new CustomerOrFirm(provider.CustomerOrFirm));

			if (provider.ClearingAccount != string.Empty)
				message.set(new ClearingAccount(provider.ClearingAccount));

			orders.Add(clOrdID, order);

			Session.sendToTarget(message, orderSessionID);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="order"></param>
		public void SendOrderCancelRequest(Order order)
		{
			string origClOrdID = null;

			foreach (KeyValuePair<string, Order> pair in orders)
			{
				if (pair.Value == order)
				{
					origClOrdID = pair.Key;

					break;
				}
			}

			if (origClOrdID != null)
			{
				string clOrdID = Guid.NewGuid().ToString();

				QuickFix42.OrderCancelRequest message = new QuickFix42.OrderCancelRequest();

				message.set(new OrigClOrdID(origClOrdID));
				message.set(new ClOrdID(clOrdID));

				message.set(new Symbol(order.Instrument.GetSymbol(TTFIX.PROVIDER_NAME)));
				message.set(new SecurityExchange(order.Instrument.GetExchange(TTFIX.PROVIDER_NAME)));

				switch (order.Side)
				{
					case OrderSide.Buy:
						message.set(new Side(Side.BUY));
						break;
					case OrderSide.Sell:
						message.set(new Side(Side.SELL));
						break;
				}

				message.set(new TransactTime(order.DateTime));

				switch (order.Instrument.Type)
				{
					case InstrumentType.Stock:
						{
							message.set(new SecurityType(SecurityType.COMMON_STOCK));
						}
						break;
					case InstrumentType.Index:
						{
							message.set(new SecurityType("IDX"));
						}
						break;
					case InstrumentType.FX:
						{
							message.set(new SecurityType(SecurityType.FOREIGN_EXCHANGE_CONTRACT));
						}
						break;
					case InstrumentType.Futures:
						{
							message.set(new SecurityType(SecurityType.FUTURE));
							message.set(new MaturityMonthYear(order.Instrument.Maturity.ToString("yyyyMM")));
						}
						break;
					case InstrumentType.Option:
						{
							message.set(new SecurityType(SecurityType.OPTION));
							message.set(new MaturityMonthYear(order.Instrument.Maturity.ToString("yyyyMM")));

							switch (order.Instrument.PutCall)
							{
								case PutCall.Put:
									message.set(new PutOrCall(PutOrCall.PUT));
									break;
								case PutCall.Call:
									message.set(new PutOrCall(PutOrCall.CALL));
									break;
							}

							message.set(new StrikePrice(order.Instrument.Strike));
						}
						break;
				}

				if (order.Account != string.Empty)
					message.set(new Account(order.Account));
				else
					message.set(new Account(provider.Account));

				Session.sendToTarget(message, orderSessionID);
			}
		}

		#region QuickFix callbacks

		public override void onMessage(QuickFix42.BusinessMessageReject message, SessionID session)
		{
			provider.OnError(string.Format("BusinessMessageReject: {0}", message));
		}

		public override void onMessage(QuickFix42.MarketDataSnapshotFullRefresh message, SessionID session)
		{
			MarketDataRecord record;

			if (marketDataRecords.TryGetValue(message.getMDReqID().getValue(), out record))
			{
				int noMDEntries = message.getNoMDEntries().getValue();

				for (uint i = 1; i <= noMDEntries; i++)
				{
					QuickFix42.MarketDataIncrementalRefresh.NoMDEntries group = new QuickFix42.MarketDataIncrementalRefresh.NoMDEntries();

					message.getGroup(i, group);

					switch (group.getMDEntryType().getValue())
					{
						case MDEntryType.TRADE:
							{
								provider.OnNewTrade(
									record.Instrument,
									group.getMDEntryPx().getValue(),
									(int)group.getMDEntrySize().getValue());
							}
							break;
					}
				}
			}
		}

		public override void onMessage(QuickFix42.MarketDataIncrementalRefresh message, SessionID session)
		{
			MarketDataRecord record;

			if (marketDataRecords.TryGetValue(message.getMDReqID().getValue(), out record))
			{
				int noMDEntries = message.getNoMDEntries().getValue();

				for (uint i = 1; i <= noMDEntries; i++)
				{
					QuickFix42.MarketDataIncrementalRefresh.NoMDEntries group = new QuickFix42.MarketDataIncrementalRefresh.NoMDEntries();

					message.getGroup(i, group);

					switch (group.getMDUpdateAction().getValue())
					{
						case MDUpdateAction.NEW:
							{
								switch (group.getMDEntryType().getValue())
								{
									case MDEntryType.TRADE:
										{
											provider.OnNewTrade(
												record.Instrument,
												group.getMDEntryPx().getValue(),
												(int)group.getMDEntrySize().getValue());
										}
										break;
								}
							}
							break;
					}
				}
			}
		}

		public override void onMessage(QuickFix42.MarketDataRequestReject message, SessionID session)
		{
			List<string> error = new List<string>();

			error.Add("MarketDataRequestReject:");

			if (message.isSetMDReqID())
				error.Add(string.Format("MDReqID={0}", message.getMDReqID().getValue()));

			if (message.isSetMDReqRejReason())
				error.Add(string.Format("MDReqRejReason={0}", message.getMDReqRejReason().getValue()));

			if (message.isSetText())
				error.Add(string.Format("Text={0}", message.getText().getValue()));

			provider.OnError(string.Join(" ", error.ToArray()));
		}

		public override void onMessage(QuickFix42.ExecutionReport message, SessionID session)
		{
			switch (message.getExecType().getValue())
			{
				case ExecType.NEW:
					{
						Order order;

						if (orders.TryGetValue(message.getClOrdID().getValue(), out order))
							provider.OnOrderAccepted(order);
					}
					break;
				case ExecType.REJECTED:
					{
						Order order;

						if (orders.TryGetValue(message.getClOrdID().getValue(), out order))
						{
							string text = (message.isSetText()) ? message.getText().getValue() : "no reason";

							provider.OnOrderRejected(order, text);
						}
					}
					break;
				case ExecType.PENDING_CANCEL:
					{
						Order order;

						if (orders.TryGetValue(message.getOrigClOrdID().getValue(), out order))
							provider.OnOrderPendingCancel(order);
					}
					break;
				case ExecType.CANCELED:
					{
						Order order;

						if (orders.TryGetValue(message.getOrigClOrdID().getValue(), out order))
							provider.OnOrderCancelled(order);
					}
					break;
				case ExecType.PARTIAL_FILL:
				case ExecType.FILL:
					{
						Order order;

						if (orders.TryGetValue(message.getClOrdID().getValue(), out order))
						{
							provider.OnOrderFilled(
								order,
								message.getLastPx().getValue(),
								(int)message.getLastShares().getValue());
						}
					}
					break;
			}
		}

		#endregion
	}
}
