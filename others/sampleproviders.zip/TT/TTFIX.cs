﻿/************************************************************************
 * Copyright(c) 1997-2008, SmartQuant Ltd. All rights reserved.         *
 *                                                                      *
 * This file is provided as is with no warranty of any kind, including  *
 * the warranty of design, merchantability and fitness for a particular *
 * purpose.                                                             *
 *                                                                      *
 * This software may not be used nor distributed without proper license *
 * agreement.                                                           *
 ************************************************************************/

using System;

using OpenQuant.API;
using OpenQuant.API.Plugins;

using QuickFix;

namespace SampleProviders.TT
{
	public partial class TTFIX : UserProvider
	{
		// Constants
		public const string PROVIDER_NAME = "TT FIX Sample";

		//
		private Initiator initiator;

		private TTFIXApplication application;

		/// <summary>
		/// 
		/// </summary>
		public TTFIX()
		{
			base.name        = PROVIDER_NAME;
			base.description = "TT FIX Sample Adapter";
			base.id          = 150;

			initiator = null;

			application = null;

			InitSettings();
		}

		#region UserProvider overloads

		/// <summary>
		/// 
		/// </summary>
		protected override void Connect()
		{
			if (isConnected)
			{
				// already connected
				return;
			}

			if (application == null)
			{
				// defaults
				Dictionary defaultsSessionSettings = new Dictionary();

				defaultsSessionSettings.setString("ConnectionType", "initiator");
				defaultsSessionSettings.setLong("HeartBtInt", HeartBtInt);
				defaultsSessionSettings.setString("StartTime", StartTime.ToString());
				defaultsSessionSettings.setString("EndTime", EndTime.ToString());
				defaultsSessionSettings.setLong("ReconnectInterval", ReconnectInterval);
				defaultsSessionSettings.setString("BeginString", BeginString);
				defaultsSessionSettings.setString("DataDictionary", DataDictionary);
				defaultsSessionSettings.setString("FileStorePath", FileStorePath);
				defaultsSessionSettings.setString("FileLogPath", FileLogPath);
				defaultsSessionSettings.setBool("CheckLatency", CheckLatency);
				defaultsSessionSettings.setBool("ResetOnLogout", ResetOnLogout);
				defaultsSessionSettings.setBool("ResetOnDisconnect", ResetOnDisconnect);

				// price settings
				Dictionary priceSessionSettings = new Dictionary();

				priceSessionSettings.setString("SocketConnectHost", PriceSocketConnectHost);
				priceSessionSettings.setLong("SocketConnectPort", PriceSocketConnectPort);
				priceSessionSettings.setString("FileStorePath", PriceFileStorePath);

				// order settings
				Dictionary orderSessionSettings = new Dictionary();

				orderSessionSettings.setString("SocketConnectHost", OrderSocketConnectHost);
				orderSessionSettings.setLong("SocketConnectPort", OrderSocketConnectPort);
				orderSessionSettings.setString("FileStorePath", OrderFileStorePath);

				// create sessions
				SessionID priceSessionID = new SessionID(BeginString, PriceSenderCompID, PriceTargetCompID);
				SessionID orderSessionID = new SessionID(BeginString, OrderSenderCompID, OrderTargetCompID);

				// session settings
				SessionSettings sessionSettings = new SessionSettings();

				sessionSettings.set(defaultsSessionSettings);
				sessionSettings.set(priceSessionID, priceSessionSettings);
				sessionSettings.set(orderSessionID, orderSessionSettings);

				// create application
				application = new TTFIXApplication(this, priceSessionID, orderSessionID);

				// create initiator
				initiator = new ThreadedSocketInitiator(
					application,
					new FileStoreFactory(sessionSettings),
					sessionSettings,
					new FileLogFactory(sessionSettings),
					new DefaultMessageFactory());

				initiator.start();
			}

			application.Connect();
		}

		/// <summary>
		/// 
		/// </summary>
		protected override void Disconnect()
		{
			if (isConnected)
				application.Disconnect();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="instrument"></param>
		protected override void Subscribe(Instrument instrument)
		{
			if (isConnected)
				application.SendMarketDataRequest(instrument, true);
			else
				EmitError("Not connected.");
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="instrument"></param>
		protected override void Unsubscribe(Instrument instrument)
		{
			if (isConnected)
				application.SendMarketDataRequest(instrument, false);
			else
				EmitError("Not connected.");
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="order"></param>
		protected override void Send(Order order)
		{
			if (isConnected)
				application.SendNewOrderSingle(order);
			else
				EmitError("Not connected.");
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="order"></param>
		protected override void Cancel(Order order)
		{
			if (isConnected)
				application.SendOrderCancelRequest(order);
			else
				EmitError("Not connected.");
		}

		#endregion

		#region Application callbacks

		/// <summary>
		/// 
		/// </summary>
		internal void OnLogon()
		{
			isConnected = true;

			EmitConnected();
		}

		/// <summary>
		/// 
		/// </summary>
		internal void OnLogout()
		{
			isConnected = false;

			EmitDisconnected();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="message"></param>
		internal void OnError(string message)
		{
			EmitError(message);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="instrument"></param>
		/// <param name="price"></param>
		/// <param name="size"></param>
		internal void OnNewTrade(Instrument instrument, double price, int size)
		{
			EmitNewTrade(instrument, Clock.Now, price, size);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="instrument"></param>
		/// <param name="bid"></param>
		/// <param name="bidSize"></param>
		/// <param name="ask"></param>
		/// <param name="askSize"></param>
		internal void OnNewQuote(Instrument instrument, double bid, int bidSize, double ask, int askSize)
		{
			EmitNewQuote(instrument, Clock.Now, bid, bidSize, ask, askSize);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="order"></param>
		internal void OnOrderAccepted(Order order)
		{
			EmitAccepted(order);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="order"></param>
		/// <param name="message"></param>
		internal void OnOrderRejected(Order order, string message)
		{
			EmitRejected(order, message);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="order"></param>
		internal void OnOrderPendingCancel(Order order)
		{
			EmitPendingCancel(order);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="order"></param>
		internal void OnOrderCancelled(Order order)
		{
			EmitCancelled(order);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="order"></param>
		/// <param name="price"></param>
		/// <param name="qty"></param>
		internal void OnOrderFilled(Order order, double price, int qty)
		{
			EmitFilled(order, price, qty);
		}

		#endregion
	}
}
