/************************************************************************
 * Copyright(c) 1997-2008, SmartQuant Ltd. All rights reserved.         *
 *                                                                      *
 * This file is provided as is with no warranty of any kind, including  *
 * the warranty of design, merchantability and fitness for a particular *
 * purpose.                                                             *
 *                                                                      *
 * This software may not be used nor distributed without proper license *
 * agreement.                                                           *
 ************************************************************************/
 
﻿using System;
using System.IO;
using System.Net;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;

using OpenQuant.API;
using OpenQuant.API.Plugins;

namespace SampleProviders.Google
{
	public class GoogleFinance : UserProvider
	{
		// Class members
		private Dictionary<HistoricalDataRequest, WebRequest> webRequests;

		private ListDictionary pendingCancels;

		/// <summary>
		/// 
		/// </summary>
		public GoogleFinance()
		{
			base.name        = "Google Sample";
			base.description = "Google Finance (user version)";
			base.id          = 107;
			base.url         = "http://www.google.com";

			webRequests = new Dictionary<HistoricalDataRequest, WebRequest>();

			pendingCancels = new ListDictionary();
		}

		/// <summary>
		/// 
		/// </summary>
		protected override void Connect()
		{
			// no special actions are needed
			if (!base.isConnected)
			{
				base.isConnected = true;

				base.EmitConnected();
			}
		}

		/// <summary>
		/// 
		/// </summary>
		protected override void Disconnect()
		{
			// no special actions are needed
			if (base.isConnected)
			{
				base.isConnected = false;

				base.EmitDisconnected();
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="request"></param>
		protected override void RequestHistoricalData(HistoricalDataRequest request)
		{
			//
			if (!base.isConnected)
			{
				EmitError("Not connected.");

				return;
			}

			//
			if (request.DataType != DataType.Daily)
			{
				EmitHistoricalDataError(request, "Only daily data requests are supported.");

				return;
			}

			//
			string symbol = request.Instrument.GetSymbol(base.name);

			string uri = string.Format(
				CultureInfo.InvariantCulture,
				"http://finance.google.com/finance/historical?q={0}&histperiod=daily&startdate={1:MMM d, yyyy}&enddate={2:MMM d, yyyy}&output=csv",
				symbol,
				request.BeginDate,
				request.EndDate);

			WebRequest webRequest = WebRequest.Create(uri);

			webRequests.Add(request, webRequest);

			webRequest.BeginGetResponse(DataCallback, request);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="request"></param>
		protected override void CancelHistoricalData(HistoricalDataRequest request)
		{
			if (!base.isConnected)
			{
				EmitError("Not connected.");

				return;
			}

			WebRequest webRequest;

			if (webRequests.TryGetValue(request, out webRequest))
			{
				pendingCancels[request] = true;

				webRequest.Abort();
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="result"></param>
		private void DataCallback(IAsyncResult result)
		{
			HistoricalDataRequest request = (HistoricalDataRequest)result.AsyncState;

			WebRequest webRequest;

			if (webRequests.TryGetValue(request, out webRequest))
			{
				webRequests.Remove(request);

				try
				{
					// read response data
					StreamReader reader = new StreamReader(webRequest.EndGetResponse(result).GetResponseStream());

					List<string> lines = new List<string>();

					string line = null;

					while ((line = reader.ReadLine()) != null)
						lines.Add(line);

					if (lines.Count > 0)
						lines.RemoveAt(0);

					lines.Reverse();

					//
					for (int i = 0; i < lines.Count; i++)
					{
						string[] items = lines[i].Split(',');

						DateTime date =	DateTime.Parse(items[0], CultureInfo.InvariantCulture);
						double open   = double.Parse(items[1], CultureInfo.InvariantCulture);
						double high   = double.Parse(items[2], CultureInfo.InvariantCulture);
						double low    = double.Parse(items[3], CultureInfo.InvariantCulture);
						double close  = double.Parse(items[4], CultureInfo.InvariantCulture);
						long volume   = long.Parse(items[5], CultureInfo.InvariantCulture);

						EmitNewHistoricalBar(
							request,
							date,
							open,
							high,
							low,
							close,
							volume);
					}

					// finish
					EmitHistoricalDataCompleted(request);
				}
				catch (Exception e)
				{
					if (pendingCancels.Contains(request))
					{
						pendingCancels.Remove(request);

						EmitHistoricalDataCancelled(request);
					}
					else
						EmitHistoricalDataError(request, e.Message);
				}
			}
		}
	}
}
