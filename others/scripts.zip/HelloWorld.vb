Imports System
Imports System.Windows.Forms
Imports System.IO
Imports System.Drawing

Imports OpenQuant.API
Imports OpenQuant.API.Indicators

Public Class MyScript
    Inherits Script

    Public Overrides Sub Run()
		MessageBox.Show("Hello World!")
    End Sub

End Class
