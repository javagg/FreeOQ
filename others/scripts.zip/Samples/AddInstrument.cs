using System;
using System.IO;
using System.Drawing;

using OpenQuant.API;
using OpenQuant.API.Indicators;

public class MyScript : Script
{
	public override void Run()
	{
		string[] symbols = new string[] {"Stock1", "Stock2", "Stock3"};
		
		foreach (string symbol in symbols)
			new Instrument(InstrumentType.Stock, symbol);
	}
}
