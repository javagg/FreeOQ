using System;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

using OpenQuant.API;
using OpenQuant.API.Indicators;

public class MyScript : Script
{
	public override void Run()
	{
		// get instrument
		Instrument instrument = InstrumentManager.Instruments["MSFT"];
		
		if (instrument == null)
			MessageBox.Show("Instrument doesn't exist");			
		
		// get daily series
		BarSeries series = DataManager.GetHistoricalBars(instrument, BarType.Time, 86400);
		
		// draw series
		if (series.Count > 0)
		{			
			Canvas canvas = new Canvas("Sample");
			
			canvas.Add(series);		
			canvas.Run();
		}
		else
			MessageBox.Show("Requested series doesn't exists or empty");
	}
}
