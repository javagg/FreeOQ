using System;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

using OpenQuant.API;
using OpenQuant.API.Indicators;

public class MyScript : Script
{
	public override void Run()
	{
		MessageBox.Show("Hello World!");
	}
}
