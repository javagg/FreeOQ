using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Text;

using OpenQuant.API;
using OpenQuant.API.Plugins;

namespace SampleIndicators
{
	public class UserBBL : UserIndicator
	{
		private int length;
		private double k;
		private BarData barData;
		
		[Category("Parameters"), Description("Length")]		
		public int Length
		{
			get { return length; }
			set { length = value; }
		}
		
		public BarData BarData
		{
			get { return barData; }
			set { barData = value; }
		}

		public double K
		{
			get { return k; }
			set { k = value; }
		}		
		
		public UserBBL(ISeries series, int length, double k, BarData barData)
			: base (series)
		{
			this.length = length;
			this.k = k;
			this.barData = barData;

			this.Name = "User BBL, Length = " + length + ", K = " + k;			
		}

		public UserBBL(ISeries series, int length, double k)
			: this(series, length, k, BarData.Close)
		{
		}

		public override double Calculate(int index)
		{
			if (index >= length - 1)
			{
				double sma = 0;
				double smv = 0;

				// calculate sma
				for (int i = index; i >= index - length + 1; i--)
					sma += Input[i, barData];

				sma /= length;

				// calculate variance
				for (int i = index; i > index - length; i--)
					smv += (sma - Input[i, barData]) * (sma - Input[i, barData]);

				smv /= length;

				return sma - k * Math.Sqrt(smv);
			}
			else
				return double.NaN;
		}
	}
}

