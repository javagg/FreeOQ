using System;
using System.Collections.Generic;
using System.Text;

using OpenQuant.API;
using OpenQuant.API.Plugins;

namespace SampleIndicators
{
	public class UserAD : UserIndicator
	{
		public UserAD(ISeries series)
			: base (series)
		{
			this.Name = "User AD";
		}

		public override double Calculate(int index)
		{
			if (index >= 0)
			{
				double ad = 0;
			
				double high   = Input[index, BarData.High  ];
				double low    = Input[index, BarData.Low   ];
				double close  = Input[index, BarData.Close ];
				double open   = Input[index, BarData.Open  ];				
				double volume = Input[index, BarData.Volume];
				
				if (index >= 1)
				{				
					if (high != low)
						ad = volume * ((close - low) - (high - close)) / (high - low) + this.Last;
					else 
						ad = this.Last;	
				}
				
				if (index == 0)
					if (high != low)
						ad = volume * ((close - low) - (high - close)) / (high - low);

				return ad;
			}
			else 
				return double.NaN;
		}
	}
}

