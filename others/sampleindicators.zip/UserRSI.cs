using System;
using System.Collections.Generic;
using System.Text;

using OpenQuant.API;
using OpenQuant.API.Plugins;

namespace SampleIndicators
{
	public class UserRSI : UserIndicator
	{
		private int length;
		private BarData barData;

		private TimeSeries upSeries;
		private TimeSeries downSeries;

		public int Length
		{
			get { return length; }
			set { length = value; }
		}
		
		public BarData BarData
		{
			get { return barData; }
			set { barData = value; }
		}
		
		public UserRSI(ISeries series, int length, BarData barData)
			: base (series)
		{
			this.length = length;
			this.barData = barData;

			upSeries   = new TimeSeries();
			downSeries = new TimeSeries();

			this.Name = "User RSI, Length = " + length;			
		}

		public UserRSI(ISeries series, int length)
			: this(series, length, BarData.Close)
		{
		}

		public override double Calculate(int index)
		{
			double curr = 0;
			double prev = 0;

			double up = 0;
			double down = 0;

			double rsi = double.NaN;

			if (index >= length)
			{
				if (index == length)
				{
					prev = Input[index - length, barData];

					for (int i = index - length + 1; i <= index; i++)
					{
						curr = Input[i, barData];

						if (curr > prev)
							up += curr - prev;
						else
							down += prev - curr;

						prev = curr;
					}
				}
				else
				{
					up = upSeries[index - 1] * length;
					down = downSeries[index - 1] * length;

					curr = Input[index, barData];
					prev = Input[index - 1, barData];

					if (curr > prev)
						up += curr - prev;
					else
						down += prev - curr;

					curr = Input[index - length, barData];
					prev = Input[index - length - 1, barData];

					if (curr > prev)
						up -= curr - prev;
					else
						down -= prev - curr;
				}
			}

			rsi = 100 - 100.0 / (1.0 + up / down);

			up /= length;
			down /= length;			

			upSeries.Add(Input.GetDateTime(index), up);
			downSeries.Add(Input.GetDateTime(index), down);

			return rsi;
		}
	}
}

