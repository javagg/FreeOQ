using System;
using System.Drawing;

using OpenQuant.API;
using OpenQuant.API.Indicators;

using SampleIndicators;

public class MyStrategy : Strategy
{
	public override void OnStrategyStart()
	{
		UserBBL bbl = new UserBBL(Bars, 14, 2);
		bbl.Color = Color.Yellow;
		Draw(bbl, 0);

		UserBBU bbu = new UserBBU(Bars, 14, 2);
		bbu.Color = Color.Yellow;
		Draw(bbu, 0);
		
		UserAD ad = new UserAD(Bars);
		ad.Color = Color.Pink;
		Draw(ad, 2);
	}

	public override void OnBar(Bar bar)
	{
	}
}